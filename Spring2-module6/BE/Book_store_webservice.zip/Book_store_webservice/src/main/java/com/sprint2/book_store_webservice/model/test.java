package com.sprint2.book_store_webservice.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class test {

    public static void main(String[] args) {
        sortString("452135aAbBd9");
        sortStringUseCollection("452135aAbBd9");
    }

    public static void sortString(String string) {
        char arr[] = new char[string.length()];
        for (int i = 0; i < string.length(); i++) {
            char character = string.charAt(i);
            for (int j = 0; j < arr.length; j++) {
                if (arr[j] != '\u0000') {
                    if (character < arr[j]) {
                        char temp = character;
                        character = arr[j];
                        arr[j] = temp;
                    }
                } else {
                    arr[j] = character;
                    break;
                }
            }
        }
        System.out.println(Arrays.toString(arr));
    }

    public static void sortStringUseCollection(String string){
        List<Character> characters = new ArrayList<>();
        for (int i = 0; i < string.length(); i++) {
            characters.add(string.charAt(i));
        }
        Collections.sort(characters);
        System.out.println(characters.toString());
    }
}
