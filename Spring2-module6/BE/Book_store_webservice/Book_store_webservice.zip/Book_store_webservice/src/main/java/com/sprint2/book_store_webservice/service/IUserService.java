package com.sprint2.book_store_webservice.service;

import com.sprint2.book_store_webservice.model.Account;
import com.sprint2.book_store_webservice.model.AppUser;
import org.springframework.data.repository.query.Param;

public interface IUserService {

    Account findByUsername(String username);

    Account findByAppUser_Email(String email);

    AppUser updateUser( Double price ,  Long id);


}
