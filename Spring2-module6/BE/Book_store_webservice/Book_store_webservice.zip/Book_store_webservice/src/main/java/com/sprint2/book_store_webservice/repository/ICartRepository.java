package com.sprint2.book_store_webservice.repository;

import com.sprint2.book_store_webservice.dto.ICartDto;
import com.sprint2.book_store_webservice.model.Cart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ICartRepository extends JpaRepository<Cart, Long> {

    @Query(value = "select c.quantity_cart as quantityCart, c.id , b.title , b.price , b.quantity , b.image_url as imageUrl " +
            "from cart as c  " +
            "join book as b " +
            "on c.book_id = b.id " +
            "join account as a " +
            "on c.account_id = a.id " +
            "where a.id = :idAccount  ", nativeQuery = true)
    List<ICartDto> findAllByCart(@Param("idAccount") Long id);

}
