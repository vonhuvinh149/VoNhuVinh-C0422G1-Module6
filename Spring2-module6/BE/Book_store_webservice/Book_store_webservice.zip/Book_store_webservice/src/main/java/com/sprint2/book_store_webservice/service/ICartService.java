package com.sprint2.book_store_webservice.service;

import com.sprint2.book_store_webservice.dto.ICartDto;
import com.sprint2.book_store_webservice.model.Cart;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ICartService {

    List<ICartDto> findAllByCart(Long id);
}
