package com.sprint2.book_store_webservice.model;

public class LoginResponse {

    private String token;

    private Long id;

    public LoginResponse(String token, Long id) {
        this.token = token;
        this.id = id;
    }

    public LoginResponse() {
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
