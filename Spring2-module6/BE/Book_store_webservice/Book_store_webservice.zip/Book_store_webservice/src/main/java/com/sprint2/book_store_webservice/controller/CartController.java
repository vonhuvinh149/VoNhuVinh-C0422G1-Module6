package com.sprint2.book_store_webservice.controller;


import com.sprint2.book_store_webservice.dto.ICartDto;
import com.sprint2.book_store_webservice.service.ICartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("/public")
public class CartController {

    @Autowired
    private ICartService iCartService;

    private ICartDto iCartDto;

    @GetMapping("/cart/{id}")
    public ResponseEntity<List<ICartDto>> cartList(@PathVariable Long id) {
        List<ICartDto> cartList = this.iCartService.findAllByCart(id);
        if (cartList.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(cartList, HttpStatus.OK);
    }
}
