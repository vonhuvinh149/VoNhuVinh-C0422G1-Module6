package com.sprint2.book_store_webservice.repository;

import com.sprint2.book_store_webservice.model.Account;
import com.sprint2.book_store_webservice.model.AppUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface IUserRepository extends JpaRepository<Account, Long> {

    Account findByUsername(String username);

    Account findByAppUser_Email(String email);

    @Query(value = "update  app_user " +
            "set app_user.money = :moneyTotal " +
            "where app_user.id = :idUser ", nativeQuery = true)
    AppUser updateUser(@Param("moneyTotal") Double price , @Param("idUser") Long id);
}
