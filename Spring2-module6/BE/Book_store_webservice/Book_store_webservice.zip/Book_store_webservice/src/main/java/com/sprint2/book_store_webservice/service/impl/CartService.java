package com.sprint2.book_store_webservice.service.impl;

import com.sprint2.book_store_webservice.dto.ICartDto;
import com.sprint2.book_store_webservice.repository.ICartRepository;
import com.sprint2.book_store_webservice.service.ICartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService implements ICartService {

    @Autowired
    private ICartRepository iCartRepository;

    @Override
    public List<ICartDto> findAllByCart(Long id) {


        return this.iCartRepository.findAllByCart(id);

    }

}
